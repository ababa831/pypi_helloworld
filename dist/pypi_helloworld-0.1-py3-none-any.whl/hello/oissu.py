print('Oissu!')
